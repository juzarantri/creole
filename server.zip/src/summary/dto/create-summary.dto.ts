export class CreateSummaryDto {}
